<?php
/**
 * The Front Page template for Evara Art (Fluid, Enhanced & Non-Clipping)
 *
 * @package EvaraArt
 * @version 1.2.0
 */

get_header(); ?>

<?php
// 1. Determine Banner Image & Alt (Custom upload or auto-fetched from newest/featured product)
$banner_source = get_theme_mod( 'evara_banner_source', 'auto' );
$custom_banner = get_theme_mod( 'evara_custom_banner_image', '' );

$hero_banner_url = '';
$hero_banner_alt = 'Art that connects to your heart - Evara Art';

if ( 'custom' === $banner_source && ! empty( $custom_banner ) ) {
	$hero_banner_url = $custom_banner;
} else {
	// Auto-fetch from WooCommerce featured product or latest artwork
	if ( class_exists( 'WooCommerce' ) ) {
		$banner_prods = wc_get_products( array(
			'status'   => 'publish',
			'limit'    => 1,
			'featured' => true,
		) );
		if ( empty( $banner_prods ) ) {
			$banner_prods = wc_get_products( array(
				'status'  => 'publish',
				'limit'   => 1,
				'orderby' => 'date',
				'order'   => 'DESC',
			) );
		}
		if ( ! empty( $banner_prods ) && has_post_thumbnail( $banner_prods[0]->get_id() ) ) {
			$hero_banner_url = get_the_post_thumbnail_url( $banner_prods[0]->get_id(), 'full' );
			$hero_banner_alt = $banner_prods[0]->get_name() . ' - Evara Art';
		}
	}
}

if ( empty( $hero_banner_url ) ) {
	$hero_banner_url = EVARA_URI . '/assets/images/hero-banner-krishna.png';
}

$hero_badge     = get_theme_mod( 'evara_hero_badge', 'Handmade in India • Bespoke Fine Art' );
$hero_title     = get_theme_mod( 'evara_hero_title', 'Art that connects to your Heart.' );
$hero_subtitle  = get_theme_mod( 'evara_hero_subtitle', 'Welcome to Evara Art – where creativity comes to life through every brushstroke. “Evara” means Gift of God, turning sacred imagination into meaningful, handcrafted wall art for your sanctuary.' );

$hero_cta1_text = get_theme_mod( 'evara_hero_cta1_text', 'Explore Canvas Paintings' );
$hero_cta1_url  = get_theme_mod( 'evara_hero_cta1_url', '' );

$hero_cta2_text = get_theme_mod( 'evara_hero_cta2_text', 'Explore Lippan Art' );
$hero_cta2_url  = get_theme_mod( 'evara_hero_cta2_url', '' );

$stat1_num   = get_theme_mod( 'evara_stat1_number', '100%' );
$stat1_label = get_theme_mod( 'evara_stat1_label', 'Handmade' );
$stat2_num   = get_theme_mod( 'evara_stat2_number', 'Pan-India' );
$stat2_label = get_theme_mod( 'evara_stat2_label', 'Collectors & Homes' );
$stat3_num   = get_theme_mod( 'evara_stat3_number', '5-Star' );
$stat3_label = get_theme_mod( 'evara_stat3_label', 'Craftsmanship' );

$phil_badge  = get_theme_mod( 'evara_phil_badge', '✦ The Sacred Heart of Evara' );
$phil_title  = get_theme_mod( 'evara_phil_title', '“Evara” — A Gift of God, Painted From The Soul' );
$phil_quote  = get_theme_mod( 'evara_phil_quote', '“Welcome to Evara Art – where creativity comes to life through every brushstroke. ‘Evara’ means Gift of God and I believe the art I create is truly a blessing and a form of divine expression.”' );

$pillar1_title = get_theme_mod( 'evara_pillar1_title', 'Crafted with Passion' );
$pillar1_desc  = get_theme_mod( 'evara_pillar1_desc', 'Each piece is crafted with passion, turning imagination into meaningful and beautiful artwork that honors divine patience.' );
$pillar2_title = get_theme_mod( 'evara_pillar2_title', 'Emotion & Inspiration' );
$pillar2_desc  = get_theme_mod( 'evara_pillar2_desc', 'My goal is to bring emotion, inspiration, and uniqueness into every space, creating a calm spiritual focal point for your home.' );
$pillar3_title = get_theme_mod( 'evara_pillar3_title', 'Connecting with Your Soul' );
$pillar3_desc  = get_theme_mod( 'evara_pillar3_desc', 'Discover art that connects with your soul — timeless handmade canvas paintings and sacred Gujarat Lippan mirror craft.' );
?>

<!-- 1. Hero Section with Authentic Background Artwork -->
<section class="evara-hero-section">
	<div class="evara-container">
		
		<!-- Visual Artwork Banner (Responsive & Fluid) -->
		<div class="hero-banner-card">
			<img src="<?php echo esc_url( $hero_banner_url ); ?>" 
			     alt="<?php echo esc_attr( $hero_banner_alt ); ?>" 
			     class="hero-banner-img"
			     width="1200" 
			     height="520" 
			     fetchpriority="high">
		</div>

		<!-- Fluid Editorial Intro (No Text Clipping) -->
		<div class="hero-editorial-wrap">
			
			<div class="hero-text-content">
				<div class="hero-badge">
					<span class="badge-dot"></span>
					<span><?php echo esc_html( $hero_badge ); ?></span>
				</div>
				
				<h1 class="hero-title">
					<?php echo wp_kses_post( $hero_title ); ?>
				</h1>
				
				<p class="hero-subtitle">
					<?php echo wp_kses_post( $hero_subtitle ); ?>
				</p>
				
				<div class="hero-cta-group">
					<a href="<?php echo esc_url( ! empty( $hero_cta1_url ) ? $hero_cta1_url : home_url( '/canvas-paintings-home-decor/' ) ); ?>" class="evara-btn btn-primary btn-lg">
						<span><?php echo esc_html( $hero_cta1_text ); ?></span>
						<i class="fa-solid fa-arrow-right"></i>
					</a>
					<a href="<?php echo esc_url( ! empty( $hero_cta2_url ) ? $hero_cta2_url : home_url( '/lippan-art-home-decor/' ) ); ?>" class="evara-btn btn-outline btn-lg">
						<span><?php echo esc_html( $hero_cta2_text ); ?></span>
					</a>
				</div>

				<div class="hero-stats-row">
					<div class="stat-item">
						<span class="stat-number"><?php echo esc_html( $stat1_num ); ?></span>
						<span class="stat-label"><?php echo esc_html( $stat1_label ); ?></span>
					</div>
					<div class="stat-divider"></div>
					<div class="stat-item">
						<span class="stat-number"><?php echo esc_html( $stat2_num ); ?></span>
						<span class="stat-label"><?php echo esc_html( $stat2_label ); ?></span>
					</div>
					<div class="stat-divider"></div>
					<div class="stat-item">
						<span class="stat-number"><?php echo esc_html( $stat3_num ); ?></span>
						<span class="stat-label"><?php echo esc_html( $stat3_label ); ?></span>
					</div>
				</div>
			</div>

			<!-- Featured Artwork Showcase Card (Dynamic from WooCommerce) -->
			<?php
			$featured_product = null;
			if ( class_exists( 'WooCommerce' ) ) {
				$featured_query = wc_get_products( array(
					'status'   => 'publish',
					'limit'    => 1,
					'featured' => true,
				) );
				if ( ! empty( $featured_query ) ) {
					$featured_product = $featured_query[0];
				} else {
					$recent_query = wc_get_products( array(
						'status'  => 'publish',
						'limit'   => 1,
						'orderby' => 'date',
						'order'   => 'DESC',
					) );
					if ( ! empty( $recent_query ) ) {
						$featured_product = $recent_query[0];
					}
				}
			}
			?>
			<div class="hero-art-showcase-card">
				<?php if ( $featured_product ) : ?>
					<a href="<?php echo esc_url( $featured_product->get_permalink() ); ?>" class="showcase-card-link">
						<div class="showcase-thumb-wrap">
							<?php echo $featured_product->get_image( 'woocommerce_thumbnail', array( 'class' => 'showcase-thumb-img', 'width' => 300, 'height' => 300 ) ); ?>
						</div>
						<div class="showcase-info-box">
							<span class="showcase-tag">✦ <?php esc_html_e( 'Featured Creation', 'evara-art' ); ?></span>
							<h3 class="showcase-title"><?php echo esc_html( $featured_product->get_name() ); ?></h3>
							<div class="showcase-price-row">
								<span class="showcase-price"><?php echo $featured_product->get_price_html(); ?></span>
								<span class="showcase-cta"><?php esc_html_e( 'View Details', 'evara-art' ); ?> <i class="fa-solid fa-arrow-right"></i></span>
							</div>
						</div>
					</a>
				<?php else : ?>
					<a href="<?php echo esc_url( home_url( '/canvas-paintings-home-decor/' ) ); ?>" class="showcase-card-link">
						<div class="showcase-thumb-wrap">
							<img src="<?php echo esc_url( $hero_banner_url ); ?>" alt="<?php esc_attr_e( 'Evara Featured Art', 'evara-art' ); ?>" class="showcase-thumb-img" width="300" height="300">
						</div>
						<div class="showcase-info-box">
							<span class="showcase-tag">✦ <?php esc_html_e( 'Original Artwork', 'evara-art' ); ?></span>
							<h3 class="showcase-title"><?php esc_html_e( 'Sacred Spiritual Artworks', 'evara-art' ); ?></h3>
							<div class="showcase-price-row">
								<span class="showcase-cta"><?php esc_html_e( 'Explore Collection', 'evara-art' ); ?> <i class="fa-solid fa-arrow-right"></i></span>
							</div>
						</div>
					</a>
				<?php endif; ?>
			</div>

		</div>

	</div>
</section>

<!-- 2. Artist Divine Philosophy Section -->
<section class="evara-philosophy-section reveal-on-scroll" id="about">
	<div class="evara-container">
		<div class="philosophy-card">
			<div class="philosophy-header">
				<span class="philosophy-badge"><?php echo esc_html( $phil_badge ); ?></span>
				<h2 class="main-heading"><?php echo esc_html( $phil_title ); ?></h2>
				<p class="philosophy-quote-lead">
					&ldquo;<?php echo wp_kses_post( $phil_quote ); ?>&rdquo;
				</p>
			</div>

			<div class="philosophy-grid">
				<div class="philosophy-col">
					<div class="col-icon"><i class="fa-solid fa-paintbrush"></i></div>
					<h3 class="col-title"><?php echo esc_html( $pillar1_title ); ?></h3>
					<p class="philosophy-desc"><?php echo esc_html( $pillar1_desc ); ?></p>
				</div>
				<div class="philosophy-col">
					<div class="col-icon"><i class="fa-solid fa-spa"></i></div>
					<h3 class="col-title"><?php echo esc_html( $pillar2_title ); ?></h3>
					<p class="philosophy-desc"><?php echo esc_html( $pillar2_desc ); ?></p>
				</div>
				<div class="philosophy-col">
					<div class="col-icon"><i class="fa-solid fa-heart"></i></div>
					<h3 class="col-title"><?php echo esc_html( $pillar3_title ); ?></h3>
					<p class="philosophy-desc"><?php echo esc_html( $pillar3_desc ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- 3. Trust Strip -->
<section class="evara-trust-strip reveal-on-scroll">
	<div class="evara-container trust-grid">
		<div class="trust-item">
			<div class="trust-icon"><i class="fa-solid fa-hand-holding-heart"></i></div>
			<div class="trust-text">
				<h4><?php esc_html_e( '100% Original Handwork', 'evara-art' ); ?></h4>
				<p><?php esc_html_e( 'Hand-painted brushstrokes on 380 GSM cotton duck canvas. Never mass machine prints.', 'evara-art' ); ?></p>
			</div>
		</div>
		<div class="trust-item">
			<div class="trust-icon"><i class="fa-solid fa-box-archive"></i></div>
			<div class="trust-text">
				<h4><?php esc_html_e( 'Reinforced Hardboard Crating', 'evara-art' ); ?></h4>
				<p><?php esc_html_e( 'Foam-padded edge protectors and wooden hardboard crating for damage-free transit.', 'evara-art' ); ?></p>
			</div>
		</div>
		<div class="trust-item">
			<div class="trust-icon"><i class="fa-solid fa-palette"></i></div>
			<div class="trust-text">
				<h4><?php esc_html_e( 'Custom Wall Sizing', 'evara-art' ); ?></h4>
				<p><?php esc_html_e( 'Tailored canvas dimensions and palettes to harmonize with your living space.', 'evara-art' ); ?></p>
			</div>
		</div>
		<div class="trust-item">
			<div class="trust-icon"><i class="fa-solid fa-truck-fast"></i></div>
			<div class="trust-text">
				<h4><?php esc_html_e( 'Insured Pan-India Delivery', 'evara-art' ); ?></h4>
				<p><?php esc_html_e( 'Safe doorstep delivery across all Indian pin codes with live dispatch tracking.', 'evara-art' ); ?></p>
			</div>
		</div>
	</div>
</section>

<!-- 4. Curated Collections -->
<?php
$canvas_cat = get_term_by( 'slug', 'canvas-painting-evara-art', 'product_cat' );
if ( ! $canvas_cat ) {
	$canvas_cat = get_term_by( 'slug', 'canvas-paintings-home-decor', 'product_cat' );
}
if ( ! $canvas_cat ) {
	$canvas_cat = get_term_by( 'slug', 'canvas-paintings', 'product_cat' );
}

$lippan_cat = get_term_by( 'slug', 'clay-art-evara-art', 'product_cat' );
if ( ! $lippan_cat ) {
	$lippan_cat = get_term_by( 'slug', 'lippan-art-home-decor', 'product_cat' );
}
if ( ! $lippan_cat ) {
	$lippan_cat = get_term_by( 'slug', 'lippan-art', 'product_cat' );
}

$canvas_count_str = ( $canvas_cat && $canvas_cat->count > 0 ) ? sprintf( esc_html__( '%d Original Works', 'evara-art' ), $canvas_cat->count ) : esc_html__( '11 Original Works', 'evara-art' );
$lippan_count_str = ( $lippan_cat && $lippan_cat->count > 0 ) ? sprintf( esc_html__( '%d Handcrafted Pieces', 'evara-art' ), $lippan_cat->count ) : esc_html__( '10 Handcrafted Pieces', 'evara-art' );

$canvas_url = $canvas_cat ? get_term_link( $canvas_cat ) : home_url( '/canvas-paintings-home-decor/' );
$lippan_url = $lippan_cat ? get_term_link( $lippan_cat ) : home_url( '/lippan-art-home-decor/' );

$canvas_img_id = $canvas_cat ? get_term_meta( $canvas_cat->term_id, 'thumbnail_id', true ) : 0;
$canvas_img_url = $canvas_img_id ? wp_get_attachment_image_url( $canvas_img_id, 'large' ) : '';
if ( empty( $canvas_img_url ) && $canvas_cat && class_exists( 'WooCommerce' ) ) {
	$canvas_prods = wc_get_products( array(
		'limit'    => 1,
		'status'   => 'publish',
		'category' => array( $canvas_cat->slug ),
	) );
	if ( ! empty( $canvas_prods ) && has_post_thumbnail( $canvas_prods[0]->get_id() ) ) {
		$canvas_img_url = get_the_post_thumbnail_url( $canvas_prods[0]->get_id(), 'large' );
	}
}
if ( empty( $canvas_img_url ) ) {
	$canvas_img_url = 'https://evaraart.in/wp-content/uploads/2026/04/10-500x500.jpg';
}

$lippan_img_id = $lippan_cat ? get_term_meta( $lippan_cat->term_id, 'thumbnail_id', true ) : 0;
$lippan_img_url = $lippan_img_id ? wp_get_attachment_image_url( $lippan_img_id, 'large' ) : '';
if ( empty( $lippan_img_url ) && $lippan_cat && class_exists( 'WooCommerce' ) ) {
	$lippan_prods = wc_get_products( array(
		'limit'    => 1,
		'status'   => 'publish',
		'category' => array( $lippan_cat->slug ),
	) );
	if ( ! empty( $lippan_prods ) && has_post_thumbnail( $lippan_prods[0]->get_id() ) ) {
		$lippan_img_url = get_the_post_thumbnail_url( $lippan_prods[0]->get_id(), 'large' );
	}
}
if ( empty( $lippan_img_url ) ) {
	$lippan_img_url = 'https://evaraart.in/wp-content/uploads/2026/06/Annapakshi-Lippan-Wall-Hanging-Set-of-2-01-500x500.jpg';
}
?>
<section class="evara-collections-section reveal-on-scroll">
	<div class="evara-container">
		<div class="section-header text-center">
			<span class="sub-heading"><?php esc_html_e( 'Curated Portfolios', 'evara-art' ); ?></span>
			<h2 class="main-heading"><?php esc_html_e( 'Explore Signature Collections', 'evara-art' ); ?></h2>
			<p class="section-desc"><?php esc_html_e( 'Select a collection below to browse original creations made to illuminate your home.', 'evara-art' ); ?></p>
		</div>

		<div class="collections-grid">
			
			<!-- Canvas Paintings -->
			<div class="collection-card">
				<a href="<?php echo esc_url( $canvas_url ); ?>" class="collection-link">
					<div class="collection-img-wrap">
						<img src="<?php echo esc_url( $canvas_img_url ); ?>" alt="<?php esc_attr_e( 'Canvas Paintings Home Decor', 'evara-art' ); ?>" width="600" height="400">
						<div class="collection-overlay"></div>
					</div>
					<div class="collection-info">
						<span class="col-count"><?php echo esc_html( $canvas_count_str ); ?></span>
						<h3 class="col-title"><?php esc_html_e( 'Canvas Paintings • Home Decor', 'evara-art' ); ?></h3>
						<p class="col-desc"><?php esc_html_e( 'Krishna, Shiv Shakti, Ganesha, and serene modern abstract portraits.', 'evara-art' ); ?></p>
						<span class="col-action"><?php esc_html_e( 'Explore Collection', 'evara-art' ); ?> <i class="fa-solid fa-arrow-right"></i></span>
					</div>
				</a>
			</div>

			<!-- Lippan Art -->
			<div class="collection-card">
				<a href="<?php echo esc_url( $lippan_url ); ?>" class="collection-link">
					<div class="collection-img-wrap">
						<img src="<?php echo esc_url( $lippan_img_url ); ?>" alt="<?php esc_attr_e( 'Lippan Art Home Decor', 'evara-art' ); ?>" width="600" height="400">
						<div class="collection-overlay"></div>
					</div>
					<div class="collection-info">
						<span class="col-count"><?php echo esc_html( $lippan_count_str ); ?></span>
						<h3 class="col-title"><?php esc_html_e( 'Lippan Art • Home Decor', 'evara-art' ); ?></h3>
						<p class="col-desc"><?php esc_html_e( 'Intricate clay dough patterns and sparkling hand-cut mirrors for auspicious walls.', 'evara-art' ); ?></p>
						<span class="col-action"><?php esc_html_e( 'Explore Collection', 'evara-art' ); ?> <i class="fa-solid fa-arrow-right"></i></span>
					</div>
				</a>
			</div>

		</div>
	</div>
</section>

<!-- 5. Featured Artworks Grid (Clean, Fluid & Non-Clipping) -->
<section class="evara-artworks-section reveal-on-scroll">
	<div class="evara-container">
		
		<div class="artworks-header-flex">
			<div>
				<span class="sub-heading"><?php esc_html_e( 'Masterpiece Gallery', 'evara-art' ); ?></span>
				<h2 class="main-heading"><?php esc_html_e( 'Featured Creations', 'evara-art' ); ?></h2>
			</div>
			<a href="<?php echo esc_url( home_url( '/canvas-paintings-home-decor/' ) ); ?>" class="view-all-link">
				<span><?php esc_html_e( 'View Full Catalog', 'evara-art' ); ?></span>
				<i class="fa-solid fa-arrow-right"></i>
			</a>
		</div>

		<div class="artworks-grid">
			<?php
			if ( class_exists( 'WooCommerce' ) ) :
				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 8,
					'post_status'    => 'publish',
				);
				$loop = new WP_Query( $args );
				if ( $loop->have_posts() ) :
					$ajax_enabled = ( 'yes' === get_option( 'woocommerce_enable_ajax_add_to_cart' ) );
					while ( $loop->have_posts() ) : $loop->the_post();
						global $product;
						if ( ! $product ) {
							continue;
						}
						?>
						<div class="artwork-card">
							<div class="art-thumbnail-wrap">
								<a href="<?php the_permalink(); ?>">
									<?php
									if ( has_post_thumbnail() ) {
										the_post_thumbnail( 'woocommerce_thumbnail', array( 'class' => 'art-img-primary', 'width' => 450, 'height' => 450 ) );
									} else {
										echo '<img src="' . esc_url( EVARA_URI . '/assets/images/hero-banner-krishna.png' ) . '" alt="' . esc_attr( get_the_title() ) . '" class="art-img-primary" width="450" height="450">';
									}
									?>
								</a>
							</div>
							<div class="art-card-details">
								<h3 class="art-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h3>
								<div class="art-price-row">
									<div class="price-val"><?php echo $product->get_price_html(); ?></div>
									<?php if ( ! $product->is_in_stock() ) : ?>
										<a href="<?php the_permalink(); ?>" class="add-to-bag-btn btn-out-of-stock">
											<?php esc_html_e( 'Out of Stock', 'evara-art' ); ?>
										</a>
									<?php elseif ( $product->is_type( 'simple' ) && $product->is_purchasable() ) : ?>
										<a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" 
										   data-product_id="<?php echo esc_attr( $product->get_id() ); ?>" 
										   data-quantity="1" 
										   class="add-to-bag-btn add_to_cart_button <?php echo $ajax_enabled ? 'ajax_add_to_cart' : ''; ?>">
											<i class="fa-solid fa-plus"></i> <?php esc_html_e( 'Add', 'evara-art' ); ?>
										</a>
									<?php else : ?>
										<a href="<?php the_permalink(); ?>" class="add-to-bag-btn">
											<i class="fa-solid fa-eye"></i> <?php esc_html_e( 'Options', 'evara-art' ); ?>
										</a>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php
					endwhile;
					wp_reset_postdata();
				endif;
			endif;
			?>
		</div>

	</div>
</section>

<?php get_footer(); ?>
